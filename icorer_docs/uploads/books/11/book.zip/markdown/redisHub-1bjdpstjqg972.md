RedisHub 是一款Redis集群中间件，帮助PHP环境平滑迁移Redis集群模式，通过中间件可以解耦业务代码和redis集群之间的关系，降低开发人员对于redis集群的理解心智。中间件实现高性能网络通信、RESP协议与Redis集群协议解析，实现集群模式下的MSET/MGET指令跨槽及并发流水吞吐，为PHP请求远程Redis集群提供更高的性能及稳定性。

# 一. 总体设计

**RedisHub在组件设计上分为以下几部分:**

1. Agent配置解析器：负责对于配置文件进行解析（后续增加统一配置中心的支持）
2. 通信组件: 包括UNIX本地监听组 和 远端Redis集群TCP长连接及连接池。
3. 协议分析器: 提供稳定的Redis协议解析及组装功能组件。
4. 协议拦截器: 主要对某些Redis命令进行拦截,调用协议插件组进行功能扩展.
5. 协议插件组: 为协议分析器添加一系列插件,对通信进行优化和功能扩展，例如集群的mset、mget、del操作。
6. 容灾器:  为Agent运行提供必要的安全保障,主要包括进程资源监控,迭代更新监控.


**  具体的组件总体架构如下图:**
![](https://doc.icorer.com/uploads/redisHub/images/m_f7a5b169e89792133e9965c3b672ad73_r.png)
# 二. 网络代理设计

**RedisHub很重要的是网络代理部分,在网络代理方面由三部分组成.**

1. 第一部分是对远程redis集群的连接池.
2. 第二部分是对本地众多php-fpm客户端的UNIX请求连接管理.
3. 第三部分是对这三端之间redis通信协议进行兼容.
![](https://doc.icorer.com/uploads/redisHub/images/m_30edcfd2c84d8135ac7de109f246198f_r.png)