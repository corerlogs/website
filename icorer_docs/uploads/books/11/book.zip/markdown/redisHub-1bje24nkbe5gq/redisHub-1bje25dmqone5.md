# SF-PHP 对接 RedisHub 改造方案

## 一、背景描述

配合商品中心进行Redis集群化改造，对接 `RedisHub` 中间件，并调整SF底层，增加业务降级逻辑。

## 二、改造方案

### 2.1、Agent 连接

由于 `RedisHub` 采用 `UNIX domain`连接，本地部署 `Agent` 的方式，不存在 `port`端口，故 `redis`连接时，无法再传递该参数，需要去掉，具体连接代码如下

```php
public function __construct($config, $prefix = 'sf-prefix:')
{
  $this->prefixH = $prefix;
  $this->redisconf = $config;
  $this->redis = new \Redis();

  try {
    $this->redis->connect($this->redisconf['host']);
  } catch (\Exception $exception) {
    Logger::getInstance()->error('Redis agent connect error, ' . $exception->getMessage() . ', ' . $this->redisconf['host']);
    try {
      //redis集群中间件服务不可用，降级
      $this->redis = new \RedisCluster(null, $this->redisconf['cluster']['node'], $this->redisconf['cluster']['timeout'], $this->redisconf['cluster']['readTimeout'], $this->redisconf['cluster']['persistent']);
    } catch (\Exception $exception) {
      Logger::getInstance()->error('RedisCluster connect error, ' . $exception->getMessage());
    }
  }
  $this->redis->setOption(\Redis::OPT_PREFIX, $prefix);
}
```

我们可以看到，原先的连接方式几乎没有改动，只是去掉了`port`参数

### 2.2、降级方案

针对 `Agent`可能产生异常的情形，我们做了降级方案，代码如上。当检测到连接异常时，采用 `PHPRedis`原生的集群方案，并发送错误日志，此降级对业务是无感知的

## 三、过多 KEY 分片

为了避免 `mget`操作大数量级的 `key`，造成性能的下降，针对超过 `200`（可自定义）数量级的 `key`进行分片操作，代码如下

```php
public function getMultiple($keys)
    {
        try {
            if (count($keys) > self::CHUNK_SIZE) {
                $data = array();
                try {
                    //针对200key以上分片读取
                    foreach (array_chunk($keys, self::CHUNK_SIZE) as $val) {
                        $data = array_merge($data, $this->redis->mget($val));
                    }
                    return $data;
                } catch (\Exception $exception) {
                    Logger::getInstance()->warn('redis getMultiple(mget) error, error message : ' . $exception->getMessage());
                    return false;
                }
            }

            return $this->redis->mget($keys);
        } catch (\Exception $ex) {
            if (strpos($ex->getMessage(), 'protocol error') !== false) {
                Logger::getInstance()->warn('protocol error : php redis getMultiple(mget) error, the key is ' . implode($keys) . '. error message : ' . $ex->getMessage());
                $this->repconnect();
            }
            return false;
        }
    }
```

我们定义了一个常量 `CHUNK_SIZE`，设置为 200，当 `key`数量大于 200 时，进行分片，每 200 `key`为单位，分批请求，再将结果进行合并返回，一旦中间出现任何错误，函数终止，返回 `false`

### 四、配置文件

业务框架需要配合修改`redis.php`配置文件,`deom` 如下

```php
<?php
// phpredis配置文件
return [
    'cache' => [
        'host' => '/tmp/redis.sock',
        'port' => '16379',
        'cluster' => [
            'node' => [
                'node1',
                'node2',
                'node3',
                'node4'
            ],
            'timeout' => 1.5,
            'readTimeout' => 1.5,
            'persistent' => true
        ]
    ],

    'log' => [
        'host' => '127.0.0.1',
        'port' => '6379'
    ],
];

```

`host`为`Agent`的`UNIX domain`文件地址

`port` 可以不填

新增 `cluster` 节点，`node` 为集群地址，`timeout` 为集群连接超时时间，`readTimeout` 为读取超时时间，`persistent` 为长连接参数

**以上参数请根据线上环境自行填写**

## 五、注意

5.1、为了应对降级方案，在使用 `RedisCluster` 对象的时候，目前线上版本的 `PHPRdis`为 5.0.0，此版本在集群模式下会有导致 `php-fpm` 进程崩溃的风险，需要升级到 5.0.2

5.2、为了提升原生 `RedisCluster` 的性能，需要在 `php.ini` 文件中加上 `redis.clusters.cache_slots = 1`