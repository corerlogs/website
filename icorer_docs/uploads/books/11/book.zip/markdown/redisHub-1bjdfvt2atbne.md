**公司目前针对redis的使用有很多场景，其中最大的场景是单实例场景，随着业务量的增加、在redis单实例模式下出现了单节点存储量高、单节点吞吐负载重等问题。 首先我们针对公司的情况进行了调研。**

##  一. Redis服务器结构图
**在线上环境中,Redis分主节点和从节点,主节点目前承载读写,从节点只负责同步备份主节点数据,一个Redis组的主备关系图如下:**

![](https://doc.icorer.com/uploads/redistun/images/m_34d41d1b1310a49bf21040f21f7a80b8_r.png)

**每两台Redis互为一组单元,两台机器内部通过不同的redis进程互为主备,这里的数据存储元数量和主节点相同,从节点只负责同步数据.**

##  二. 单实例的困境

### 2.1 线上异常状况
商城部门中的商品组及运维部门反馈，由于目前PHP系统缺乏对于Redis数据的分布式存储机制，造成了Redis单节点存储量大、单节点吞吐负载重、单节点扩容困难、单节点容灾不佳等线上问题。

下图是商品中心单节点Redis的存储情况，从图中可以看出消耗内存高达20GB。
![](https://doc.icorer.com/uploads/redisHub/images/m_d33f93b5f553431468d06c072d4d1550_r.png)
从下图可以看出Redis单实例模式下的吞吐负载非常重。
![](https://doc.icorer.com/uploads/redisHub/images/m_e9ab018f1f072be04a4ae3b26f457348_r.png)

### 2.2 解决方案探索
在这种情况下，商品中心和运维部门提出希望把系统所用的Redis单节点改造为多节点存储，运维希望借助Redis集群构建具有高容性的分布式存储方案。

商品中心内部技术人员首先进行了分析，系统中大量使用Redis的mget指令，但是这种指令在Redis官方版本的集群模式中不支持跨槽位的mget， 所以在这种情况下，不进行大量业务代码调整是无法使用Redis集群的，示意图如下所示。
![](https://doc.icorer.com/uploads/redisHub/images/m_86bb7ce389715a7a5a7192911b6c7649_r.png)

随后，我对业务方使用的redis客户端（phpredis）进行了集群模式下的mget指令压力测试，发现组件存在很严重的性能问题，主要由于PHP内核缺乏并发模式，因此完全不能支撑商品中心此类对C业务，需要一个更高性能的解决方案，相关示意图如下所示：

![](https://doc.icorer.com/uploads/redisHub/images/m_c7bb9969c8bab56ce6c9c22852d95440_r.png)

在上面的情况下，商品中心和运维部门联合向公共平台架构部门提出需求，希望公共平台架构部研发一款针对PHP环境的Redis集群中间，中间件能够在业务方几乎不需要调整业务代码的情况下，帮助PHP转发Redis集群请求，并尽可能的高性能，尽量减少对于业务方的性能损耗，因此我们提出了中间件集群模式，帮助业务快速接入集群模式，示意图如下所示：

![](https://doc.icorer.com/uploads/redisHub/images/m_33d6eb352f4f93041a35ea89dc60af9f_r.png)