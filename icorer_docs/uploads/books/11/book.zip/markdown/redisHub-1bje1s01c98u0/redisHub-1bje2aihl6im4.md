## 一. 系统设计

### 1.1 背景描述

由于商城-商品中心系统目前使用的Redis单实例模式下，出现了机器存储过高、单机无法应对黑五大流量吞吐，因此进行单实例向集群化的改造，但是由于存在以下两种原因，造成需要自研中间件：

- Redis标准集群不支持跨数据槽的MGET、MSET指令。
- PHP生态缺乏并发支持，造成在M指令上性能很差。

最终我们设计RedisHub集群中间件，一方面用它来支持跨数据槽的MSET、MGET指令，一方面借助它的并发优势为PHP底层的M指令指令提高性能。

### 1.2 总体设计

中间件的总体结构设计图如下所示:

![](https://doc.icorer.com/uploads/redisHub/images/m_bfbef68f53dd5354dddeaa2f6688a8a6_r.png)

### 1.3 设计阐述

如图所示，PHP通过Unix Domain Socket途径和中间件进行IPC通信，然后中间件把PHP的redis请求进行处理，并转发到下游的Redis集群中，为PHP业务系统提供无缝的单实例到集群的改造，相关的网络模型如下：

![](https://doc.icorer.com/uploads/redisHub/images/m_638a125cc8e2352535f559d8f807d243_r.png)

## 二. 组件部署文档

**RedisHub中间件 部署主要分为两个部分, 安装相关安装包 和 修改配置并运行**.

### 2.1 部署准备

1. Linux 64bit 操作系统
2. RedisHub 二进制文件
3. 调整Redishub配置文件：rh_config.yaml
4. RedisHub进程监控工具 ,例如Supervisor

### 2.2 应用体安装

#### 2.2.1 程序体获取

最新版本的中间件程序可以联系公共平台架构部门-开发二组获取，我们编译了Linux-64bit可执行程序，给予X运行权限，即可运行。

#### 2.2.2 程序体运行

由于中间件是个可以方便运行的二进制体，但是我们在运行的时候需要制定配置文件路径，例如以下命令：

` ./RedisHub  -c  /home/corerman/DATA/ICODE/GoLang/RedisHub/config/rh_config.yaml`

具体运行参数，运维伙伴可以自行调整。

## 三. 配置文件详解

**配置文件（rh_config.yaml）是这个系统运行的基础，所以这里将讲解配置文件的相关信息.**

```shell
#RedisHub YAML config file

#RedisHub Net Config
net:
  listen_uri: unix:/tmp/redis.sock    #Unix Domain Socket的监听路径：PHP推荐使用这种模式
  #listen_uri: tcp:10.100.183.180:16379 #TCP的监控IP及端口

#RedisHub cluster Config
cluster:
  start_nodes: 10.54.2.8:9736,10.54.2.9:9736,10.54.2.10:9736 #Redis集群的节点，这里可以根据线上实际情况进行配置，多个只是为了保障高可用
  conn_timeout: 50       #Redis节点的TCP连接超时时间 （单位：毫秒）
  conn_read_timeout: 50   #Redis节点的TCP读取超时时间 （单位：毫秒）
  conn_write_timeout: 50   #Redis节点的TCP写入超时时间 （单位：毫秒）
  conn_alive_timeout: 60 #Redis节点的TCP最大空闲时间 （单位：秒）
  conn_pool_size: 150       #针对每一个Redis集群节点的TCP连接池最大值 （单位：个）

#RedisHub api config
api:
  http_listen_address:

#RedisHub log config
# log 相关配置
log:

  # 日否开启日志
  enable: true      #是否开启日志功能（true 或 false）

  # 日志输出位置，支持std(终端) kafka
  # 注：std仅在调试时使用
  output: "kafka"

  # kafka server的地址 需要修改到指定环境的kafka
  kafka_address: ["192.168.205.10:9092",
                  "192.168.205.11:9092",
                  "192.168.205.12:9092"]

  kafka_info_topic: "ltlog-info"

  kafka_error_topic: "ltlog-error"

  # 日志输出级别控制, 可省略, 默认输出到 error 级别
  # 高级别的可以输出低级别的日志， 级别 trace > debug > error > warning > info
  # 例如 level = error时，不可输出trace和debug级别的日志
  level: "error"

  #   日志中是否报告函数调用信息,可省略 默认为false
  report_call: false

  # 机器ip，可为空，默认自动查找
  ip: ""

  # 机器hostname，可为空，默认自动查找
  hostname: ""

  # app_name 默认为 RedisHub
  app_name: "RedisHub"

  # 周期上报redis执行信息 （当前是数量）
  heartbeat_report_second: 120

```

## 四 . 稳定性保障方案

### 4.1 进程稳定保障

RedisHub中间件采用多线程-协程-多核编程,有很好的并发处理能力,经过较为严格的测试没出现过崩溃情况,但是对操作系统目前指抛出一个进程,为了保障RedisHub的运行稳定性 , 所以需要给予配置一个进程监控程序,可以使用Supervisor .

### 4.2 更新配置

目前仅能通过修改配置文件来更新配置文件,如果需要更新配置,执行的操作有以下两步:

1. 更新配置文件
2. 重启应用体

## 五. 运行校验

可以通过redis-cli工具连接redisHub中间件，然后测试set\get\mset\mget指令的运行状况，从而判断中间件的运行状况。

![](https://doc.icorer.com/uploads/redisHub/images/m_5f9ac971d4199acf1c6edbed26b4a2d9_r.png)