# NetHandle

This is a library for building high-performance TCP server applications, standing on the shoulders of Go giants and redcon

## 1. Features

1. High performance, low resource consumption
2. Very easy to use development interface

## 2. Install

go get -u uriModule/NetHandle



## 3. Performance Testing:

### 3.1  50*10000 (50 threads X 10000 requests)

![](https://blog.icorer.com/usr/uploads/2019/01/1394302958.png)

![](https://blog.icorer.com/usr/uploads/2019/01/3786025671.png)

### 3.2  50*20000 (50 threads X 20000 requests)

![](https://blog.icorer.com/usr/uploads/2019/01/1563343670.png)

### 3.3  100*10000 (100 threads X 10000 requests)

![](https://blog.icorer.com/usr/uploads/2019/01/1257587320.png)