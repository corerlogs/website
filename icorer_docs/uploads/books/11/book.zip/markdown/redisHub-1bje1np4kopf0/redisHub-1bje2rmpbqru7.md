### 零、亿级数据压测

```php
// 测试脚本
<?php

$redis = new Redis();

try {
    //connect 是 异常级别
    $redis->connect('/tmp/redis.socks');

    $ret = $redis->set("hello", "helloworld",2);
    var_dump($ret);

    $ret = $redis->get("hello");
    var_dump($ret);

    $ret = $redis->del("hello");
    var_dump($ret);

    $ret = $redis->mset(["test1" => 'value1', "test2" => 'value2']);
    var_dump($ret);

    $ret = $redis->del("test1", "test2", "test3");
    var_dump($ret);

    $ret = $redis->mget(["test1", "test2", "test3", "test4", "test5", "test6", "test7", "test8", "test9", "test10", "test11", "test12", "test13", "test14", "test15", "test16", "test17", "test18", "test19", "test20"]);
    var_dump($ret);

    $ret = $redis->rPush("push","key1",2019,"key2");
    var_dump($ret);

    $val1 = $redis->lPop("push");
    var_dump($val1);
    $val1 = $redis->lPop("push");
    var_dump($val1);
    $val1 = $redis->lPop("push");
    var_dump($val1);

} catch (\Exception $ex) {
    var_dump($ex->getMessage());
}


```

```shell
# 终端输出
 ______            _ _      _     _       _     
(_____ \          | (_)    (_)   (_)     | |    
 _____) )_____  __| |_  ___ _______ _   _| |__  
|  __  /| ___ |/ _  | |/___)  ___  | | | |  _ \ 
| |  \ \| ____( (_| | |___ | |   | | |_| | |_) )
|_|   |_|_____)\____|_(___/|_|   |_|____/|____/ 

2019/09/15 09:40:27 main.go:69: UNIX-Server: /tmp/redis.socks
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"RedisHub Heart-Beat-Report running.","timestamp":"2019-09-15T09:40:27.222+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"RedisHub-UNIX begin running","timestamp":"2019-09-15T09:40:27.222+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  1978910","timestamp":"2019-09-15T09:42:27.222+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  3674420","timestamp":"2019-09-15T09:44:27.222+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  7971749","timestamp":"2019-09-15T09:46:27.223+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  13502078","timestamp":"2019-09-15T09:48:27.223+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  19082608","timestamp":"2019-09-15T09:50:27.224+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  24676646","timestamp":"2019-09-15T09:52:27.224+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  30279296","timestamp":"2019-09-15T09:54:27.225+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  35869386","timestamp":"2019-09-15T09:56:27.225+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  41462169","timestamp":"2019-09-15T09:58:27.226+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  47037700","timestamp":"2019-09-15T10:00:27.227+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  52639532","timestamp":"2019-09-15T10:02:27.227+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  58224711","timestamp":"2019-09-15T10:04:27.229+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  63814850","timestamp":"2019-09-15T10:06:27.229+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  69385735","timestamp":"2019-09-15T10:08:27.229+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  74981851","timestamp":"2019-09-15T10:10:27.230+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  80565352","timestamp":"2019-09-15T10:12:27.230+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  86114343","timestamp":"2019-09-15T10:14:27.231+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  91721982","timestamp":"2019-09-15T10:16:27.231+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  97338179","timestamp":"2019-09-15T10:18:27.231+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  102913090","timestamp":"2019-09-15T10:20:27.231+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  102913090","timestamp":"2019-09-15T10:22:27.232+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  102913090","timestamp":"2019-09-15T10:24:27.232+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  102913090","timestamp":"2019-09-15T10:26:27.233+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  102913100","timestamp":"2019-09-15T10:28:27.233+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  102913270","timestamp":"2019-09-15T10:30:27.340+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  102913270","timestamp":"2019-09-15T10:32:27.341+0800"}
{"appName":"RedisHub","host":"corerman-WorkStation","ip":"","level":"INFO","message":"heartbeat report info: command parse count :  102913270","timestamp":"2019-09-15T10:34:27.341+0800"}

```

### 一、Redis基准压测性能对比



```shell
corerman@corerman-WorkStation:~$ redis-benchmark -p 6379 -t get,set,rpush,lpop,setex,psetex,del -n 200000 -c 50 -q
SET: 129785.85 requests per second
GET: 128865.98 requests per second
RPUSH: 131839.16 requests per second
LPOP: 131061.59 requests per second

corerman@corerman-WorkStation:~$ redis-benchmark -s /tmp/redis.socks -t get,set,rpush,lpop,setex,psetex,del -n 200000 -c 50 -q
SET: 116754.23 requests per second
GET: 105932.20 requests per second
RPUSH: 116686.12 requests per second
LPOP: 105652.41 requests per second

```



通过上面可以看出，SET、GET、RPUSH、LPOP性能损耗不大



### 二. 中间件和标准集群下，phpredis的表现及性能

phpredis 5.0.2版本 需要在php.ini 中增加 `redis.clusters.cache_slots = 1`，开启redis集群的slots信息缓存，总而提升性能。

#### 2.1 SET指令 （OK）

##### 2.1.1 中间件

 ```php
<?php
$redis = new Redis();
try{
    //connect 是 异常级别
    $redis->connect('/tmp/redis.socks');

    $status = $redis->set("test","testval");
    var_dump($status);
}catch (\Exception $ex){
    var_dump($ex->getMessage());
}
 ```

运行结果：bool(true)

##### 2.1.2 标准集群

```php
<?php

try{
    //connect 是 异常级别
    $redisCluster = new RedisCluster(NULL, Array("127.0.0.1:9001"), 1.5, 1.5, true);

    $status = $redisCluster->set("test","testval");
    var_dump($status);

}catch (\Exception $ex){
    var_dump($ex->getMessage());
}
```

运行结果：bool(true)

##### 2.1.3 压测数据对比

``` shell
#中间件
corerman@corerman-WorkStation:~$ ab -n 100000 -c 20 http://lab.test.local/redis_agent.php
This is ApacheBench, Version 2.3 <$Revision: 1807734 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking lab.test.local (be patient)
Completed 10000 requests
Completed 20000 requests
Completed 30000 requests
Completed 40000 requests
Completed 50000 requests
Completed 60000 requests
Completed 70000 requests
Completed 80000 requests
Completed 90000 requests
Completed 100000 requests
Finished 100000 requests


Server Software:        nginx
Server Hostname:        lab.test.local
Server Port:            80

Document Path:          /redis_agent.php
Document Length:        11 bytes

Concurrency Level:      20
Time taken for tests:   6.229 seconds
Complete requests:      100000
Failed requests:        0
Total transferred:      19000000 bytes
HTML transferred:       1100000 bytes
Requests per second:    16054.15 [#/sec] (mean)
Time per request:       1.246 [ms] (mean)
Time per request:       0.062 [ms] (mean, across all concurrent requests)
Transfer rate:          2978.80 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   0.1      0       2
Processing:     0    1   2.9      1     213
Waiting:        0    1   2.9      1     213
Total:          0    1   2.9      1     213

Percentage of the requests served within a certain time (ms)
  50%      1
  66%      1
  75%      1
  80%      1
  90%      2
  95%      2
  98%      3
  99%      4
 100%    213 (longest request)
```

```shell
# phpredis直连标准集群 ： 开启slot缓存

corerman@corerman-WorkStation:~$ ab -n 100000 -c 20 http://lab.test.local/redis_cluster.php
This is ApacheBench, Version 2.3 <$Revision: 1807734 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking lab.test.local (be patient)
Completed 10000 requests
Completed 20000 requests
Completed 30000 requests
Completed 40000 requests
Completed 50000 requests
Completed 60000 requests
Completed 70000 requests
Completed 80000 requests
Completed 90000 requests
Completed 100000 requests
Finished 100000 requests


Server Software:        nginx
Server Hostname:        lab.test.local
Server Port:            80

Document Path:          /redis_cluster.php
Document Length:        11 bytes

Concurrency Level:      20
Time taken for tests:   5.609 seconds
Complete requests:      100000
Failed requests:        0
Total transferred:      19000000 bytes
HTML transferred:       1100000 bytes
Requests per second:    17829.52 [#/sec] (mean)
Time per request:       1.122 [ms] (mean)
Time per request:       0.056 [ms] (mean, across all concurrent requests)
Transfer rate:          3308.21 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   0.1      0       1
Processing:     0    1   2.0      1     213
Waiting:        0    1   2.0      1     212
Total:          0    1   2.0      1     213

Percentage of the requests served within a certain time (ms)
  50%      1
  66%      1
  75%      1
  80%      1
  90%      2
  95%      2
  98%      2
  99%      3
 100%    213 (longest request)

 # phpredis直连标准集群 ： 未开启slot缓存

 corerman@corerman-WorkStation:~$ ab -n 100000 -c 20 http://lab.test.local/redis_cluster.php
This is ApacheBench, Version 2.3 <$Revision: 1807734 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking lab.test.local (be patient)
Completed 10000 requests
Completed 20000 requests
Completed 30000 requests
Completed 40000 requests
Completed 50000 requests
Completed 60000 requests
Completed 70000 requests
Completed 80000 requests
Completed 90000 requests
Completed 100000 requests
Finished 100000 requests


Server Software:        nginx
Server Hostname:        lab.test.local
Server Port:            80

Document Path:          /redis_cluster.php
Document Length:        11 bytes

Concurrency Level:      20
Time taken for tests:   10.369 seconds
Complete requests:      100000
Failed requests:        0
Total transferred:      19000000 bytes
HTML transferred:       1100000 bytes
Requests per second:    9643.96 [#/sec] (mean)
Time per request:       2.074 [ms] (mean)
Time per request:       0.104 [ms] (mean, across all concurrent requests)
Transfer rate:          1789.41 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   3.2      0    1018
Processing:     1    2   4.1      2     214
Waiting:        1    2   4.1      2     214
Total:          1    2   5.2      2    1021

Percentage of the requests served within a certain time (ms)
  50%      2
  66%      2
  75%      2
  80%      2
  90%      2
  95%      2
  98%      3
  99%      3
 100%   1021 (longest request)

```

#### 2.2 SETEX指令 （OK）

##### 2.2.1 中间件

```php
<?php
$redis = new Redis();
try{
    //connect 是 异常级别
    $redis->connect('/tmp/redis.socks');

    $status = $redis->set("test","testval"，5);  //内部调用setex
    var_dump($status);
}catch (\Exception $ex){
    var_dump($ex->getMessage());
}
```

运行结果：bool(true)

##### 2.2.2 标准集群

```php
<?php

try{
    //connect 是 异常级别
      $redis = new RedisCluster(NULL, Array("127.0.0.1:9001"), 1.5, 1.5, true);

    $status = $redis->set("test","testval"，5); //内部调用setex
    var_dump($status);
}catch (\Exception $ex){
    var_dump($ex->getMessage());
}
```

运行结果：bool(true)

##### 2.2.3 压测数据对比

```shell
# 中间件
corerman@corerman-WorkStation:~$ ab -n 100000 -c 20 http://lab.test.local/redis_agent.php
This is ApacheBench, Version 2.3 <$Revision: 1807734 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking lab.test.local (be patient)
Completed 10000 requests
Completed 20000 requests
Completed 30000 requests
Completed 40000 requests
Completed 50000 requests
Completed 60000 requests
Completed 70000 requests
Completed 80000 requests
Completed 90000 requests
Completed 100000 requests
Finished 100000 requests


Server Software:        nginx
Server Hostname:        lab.test.local
Server Port:            80

Document Path:          /redis_agent.php
Document Length:        11 bytes

Concurrency Level:      20
Time taken for tests:   6.258 seconds
Complete requests:      100000
Failed requests:        0
Total transferred:      19000000 bytes
HTML transferred:       1100000 bytes
Requests per second:    15979.34 [#/sec] (mean)
Time per request:       1.252 [ms] (mean)
Time per request:       0.063 [ms] (mean, across all concurrent requests)
Transfer rate:          2964.92 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   0.1      0       1
Processing:     0    1   2.6      1     211
Waiting:        0    1   2.6      1     211
Total:          0    1   2.6      1     211

Percentage of the requests served within a certain time (ms)
  50%      1
  66%      1
  75%      1
  80%      1
  90%      2
  95%      2
  98%      3
  99%      3
 100%    211 (longest request)

```

```shell
# 标准集群

corerman@corerman-WorkStation:~$ ab -n 100000 -c 20 http://lab.test.local/redis_cluster.php
This is ApacheBench, Version 2.3 <$Revision: 1807734 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking lab.test.local (be patient)
Completed 10000 requests
Completed 20000 requests
Completed 30000 requests
Completed 40000 requests
Completed 50000 requests
Completed 60000 requests
Completed 70000 requests
Completed 80000 requests
Completed 90000 requests
Completed 100000 requests
Finished 100000 requests


Server Software:        nginx
Server Hostname:        lab.test.local
Server Port:            80

Document Path:          /redis_cluster.php
Document Length:        11 bytes

Concurrency Level:      20
Time taken for tests:   5.600 seconds
Complete requests:      100000
Failed requests:        0
Total transferred:      19000000 bytes
HTML transferred:       1100000 bytes
Requests per second:    17858.46 [#/sec] (mean)
Time per request:       1.120 [ms] (mean)
Time per request:       0.056 [ms] (mean, across all concurrent requests)
Transfer rate:          3313.58 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   0.1      0       1
Processing:     0    1   2.0      1     209
Waiting:        0    1   2.0      1     209
Total:          0    1   2.0      1     210

Percentage of the requests served within a certain time (ms)
  50%      1
  66%      1
  75%      1
  80%      1
  90%      2
  95%      2
  98%      2
  99%      3
 100%    210 (longest request)
```

#### 2.3 PSETEX指令 （OK）

##### 2.3.1 中间件

```php
<?php
$redis = new Redis();
try{
    //connect 是 异常级别
    $redis->connect('/tmp/redis.socks');

   $status = $redis->set("test","testval", ['xx', 'px'=>1000]);
    var_dump($status);
}catch (\Exception $ex){
    var_dump($ex->getMessage());
}
```

运行结果：bool(true)

##### 2.3.2 标准集群

```php
<?php

try{
    //connect 是 异常级别
    $redisCluster = new RedisCluster(NULL, Array("127.0.0.1:9001"), 1.5, 1.5, true);

    $status = $redisCluster->set("test","testval", ['xx', 'px'=>1000]);
    var_dump($status);

}catch (\Exception $ex){
    var_dump($ex->getMessage());
}
```

运行结果：bool(true)

##### 2.3.3 压测数据对比

```shell
# 中间件
corerman@corerman-WorkStation:~$ ab -n 100000 -c 20 http://lab.test.local/redis_agent.php
This is ApacheBench, Version 2.3 <$Revision: 1807734 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking lab.test.local (be patient)
Completed 10000 requests
Completed 20000 requests
Completed 30000 requests
Completed 40000 requests
Completed 50000 requests
Completed 60000 requests
Completed 70000 requests
Completed 80000 requests
Completed 90000 requests
Completed 100000 requests
Finished 100000 requests


Server Software:        nginx
Server Hostname:        lab.test.local
Server Port:            80

Document Path:          /redis_agent.php
Document Length:        11 bytes

Concurrency Level:      20
Time taken for tests:   6.265 seconds
Complete requests:      100000
Failed requests:        0
Total transferred:      19000000 bytes
HTML transferred:       1100000 bytes
Requests per second:    15962.77 [#/sec] (mean)
Time per request:       1.253 [ms] (mean)
Time per request:       0.063 [ms] (mean, across all concurrent requests)
Transfer rate:          2961.84 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   0.1      0       1
Processing:     0    1   2.9      1     213
Waiting:        0    1   2.9      1     213
Total:          0    1   2.9      1     213

Percentage of the requests served within a certain time (ms)
  50%      1
  66%      1
  75%      1
  80%      1
  90%      2
  95%      2
  98%      3
  99%      4
 100%    213 (longest request)

```

```shell
# 标准集群
corerman@corerman-WorkStation:~$ ab -n 100000 -c 20 http://lab.test.local/redis_cluster.php
This is ApacheBench, Version 2.3 <$Revision: 1807734 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking lab.test.local (be patient)
Completed 10000 requests
Completed 20000 requests
Completed 30000 requests
Completed 40000 requests
Completed 50000 requests
Completed 60000 requests
Completed 70000 requests
Completed 80000 requests
Completed 90000 requests
Completed 100000 requests
Finished 100000 requests


Server Software:        nginx
Server Hostname:        lab.test.local
Server Port:            80

Document Path:          /redis_cluster.php
Document Length:        11 bytes

Concurrency Level:      20
Time taken for tests:   5.696 seconds
Complete requests:      100000
Failed requests:        0
Total transferred:      19000000 bytes
HTML transferred:       1100000 bytes
Requests per second:    17555.61 [#/sec] (mean)
Time per request:       1.139 [ms] (mean)
Time per request:       0.057 [ms] (mean, across all concurrent requests)
Transfer rate:          3257.39 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   0.1      0       3
Processing:     0    1   1.8      1     214
Waiting:        0    1   1.8      1     214
Total:          0    1   1.8      1     214

Percentage of the requests served within a certain time (ms)
  50%      1
  66%      1
  75%      1
  80%      1
  90%      2
  95%      2
  98%      3
  99%      4
 100%    214 (longest request)

```

#### 2.4 GET指令 （数据存在：1KB 标准数据） （OK）

##### 2.4.1 中间件

```php
<?php
$redis = new Redis();
try{
    //connect 是 异常级别
    $redis->connect('/tmp/redis.socks');

    $ret = $redis->get("test");
    var_dump($ret);
}catch (\Exception $ex){
    var_dump($ex->getMessage());
}
```

能够成功获取到1KB数据。

##### 2.4.2 标准集群

```php
<?php

try{
    //connect 是 异常级别
     $redis = new RedisCluster(NULL, Array("127.0.0.1:9001"), 1.5, 1.5, true);

    $ret = $redis->get("test");
    var_dump($ret);
}catch (\Exception $ex){
    var_dump($ex->getMessage());
}
```

能够成功获取到1KB数据。

##### 2.4.3 压测数据对比

```shell
# 中间件

corerman@corerman-WorkStation:~$ ab -n 100000 -c 20 http://lab.test.local/redis_agent.php
This is ApacheBench, Version 2.3 <$Revision: 1807734 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking lab.test.local (be patient)
Completed 10000 requests
Completed 20000 requests
Completed 30000 requests
Completed 40000 requests
Completed 50000 requests
Completed 60000 requests
Completed 70000 requests
Completed 80000 requests
Completed 90000 requests
Completed 100000 requests
Finished 100000 requests


Server Software:        nginx
Server Hostname:        lab.test.local
Server Port:            80

Document Path:          /redis_agent.php
Document Length:        0 bytes

Concurrency Level:      20
Time taken for tests:   6.025 seconds
Complete requests:      100000
Failed requests:        0
Total transferred:      17900000 bytes
HTML transferred:       0 bytes
Requests per second:    16597.96 [#/sec] (mean)
Time per request:       1.205 [ms] (mean)
Time per request:       0.060 [ms] (mean, across all concurrent requests)
Transfer rate:          2901.40 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   0.1      0       2
Processing:     0    1   2.8      1     213
Waiting:        0    1   2.8      1     213
Total:          0    1   2.8      1     214

Percentage of the requests served within a certain time (ms)
  50%      1
  66%      1
  75%      1
  80%      1
  90%      2
  95%      2
  98%      3
  99%      3
 100%    214 (longest request)

```

```shell
# 标准集群

corerman@corerman-WorkStation:~$ ab -n 100000 -c 20 http://lab.test.local/redis_cluster.php
This is ApacheBench, Version 2.3 <$Revision: 1807734 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking lab.test.local (be patient)
Completed 10000 requests
Completed 20000 requests
Completed 30000 requests
Completed 40000 requests
Completed 50000 requests
Completed 60000 requests
Completed 70000 requests
Completed 80000 requests
Completed 90000 requests
Completed 100000 requests
Finished 100000 requests


Server Software:        nginx
Server Hostname:        lab.test.local
Server Port:            80

Document Path:          /redis_cluster.php
Document Length:        0 bytes

Concurrency Level:      20
Time taken for tests:   5.314 seconds
Complete requests:      100000
Failed requests:        0
Total transferred:      17900000 bytes
HTML transferred:       0 bytes
Requests per second:    18818.88 [#/sec] (mean)
Time per request:       1.063 [ms] (mean)
Time per request:       0.053 [ms] (mean, across all concurrent requests)
Transfer rate:          3289.63 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   0.1      0       2
Processing:     0    1   1.8      1     213
Waiting:        0    1   1.8      1     212
Total:          0    1   1.8      1     213

Percentage of the requests served within a certain time (ms)
  50%      1
  66%      1
  75%      1
  80%      1
  90%      1
  95%      2
  98%      2
  99%      3
 100%    213 (longest request)

```

#### 2.5 GET指令 （数据不存在） （OK）

##### 2.5.1 中间件

```php
<?php
$redis = new Redis();
try{
    //connect 是 异常级别
    $redis->connect('/tmp/redis.socks');

    $ret = $redis->get("test");
    var_dump($ret);
}catch (\Exception $ex){
    var_dump($ex->getMessage());
}
```

运行结果：bool(false)

##### 2.5.2 标准集群

```php
<?php

try{
    //connect 是 异常级别
     $redis = new RedisCluster(NULL, Array("127.0.0.1:9001"), 1.5, 1.5, true);

    $ret = $redis->get("test");
    var_dump($ret);
}catch (\Exception $ex){
    var_dump($ex->getMessage());
}
```

运行结果：bool(false)

##### 2.5.3 压测数据对比

```shell
# 中间件
corerman@corerman-WorkStation:~$ ab -n 100000 -c 20 http://lab.test.local/redis_agent.php
This is ApacheBench, Version 2.3 <$Revision: 1807734 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking lab.test.local (be patient)
Completed 10000 requests
Completed 20000 requests
Completed 30000 requests
Completed 40000 requests
Completed 50000 requests
Completed 60000 requests
Completed 70000 requests
Completed 80000 requests
Completed 90000 requests
Completed 100000 requests
Finished 100000 requests


Server Software:        nginx
Server Hostname:        lab.test.local
Server Port:            80

Document Path:          /redis_agent.php
Document Length:        12 bytes

Concurrency Level:      20
Time taken for tests:   6.012 seconds
Complete requests:      100000
Failed requests:        0
Total transferred:      19100000 bytes
HTML transferred:       1200000 bytes
Requests per second:    16632.40 [#/sec] (mean)
Time per request:       1.202 [ms] (mean)
Time per request:       0.060 [ms] (mean, across all concurrent requests)
Transfer rate:          3102.33 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   0.1      0       2
Processing:     0    1   2.9      1     213
Waiting:        0    1   2.9      1     213
Total:          0    1   2.9      1     213

Percentage of the requests served within a certain time (ms)
  50%      1
  66%      1
  75%      1
  80%      1
  90%      2
  95%      2
  98%      3
  99%      3
 100%    213 (longest request)

```

```shell
# 标准集群
corerman@corerman-WorkStation:~$ ab -n 100000 -c 20 http://lab.test.local/redis_cluster.php
This is ApacheBench, Version 2.3 <$Revision: 1807734 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking lab.test.local (be patient)
Completed 10000 requests
Completed 20000 requests
Completed 30000 requests
Completed 40000 requests
Completed 50000 requests
Completed 60000 requests
Completed 70000 requests
Completed 80000 requests
Completed 90000 requests
Completed 100000 requests
Finished 100000 requests


Server Software:        nginx
Server Hostname:        lab.test.local
Server Port:            80

Document Path:          /redis_cluster.php
Document Length:        12 bytes

Concurrency Level:      20
Time taken for tests:   5.313 seconds
Complete requests:      100000
Failed requests:        0
Total transferred:      19100000 bytes
HTML transferred:       1200000 bytes
Requests per second:    18822.79 [#/sec] (mean)
Time per request:       1.063 [ms] (mean)
Time per request:       0.053 [ms] (mean, across all concurrent requests)
Transfer rate:          3510.89 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   0.1      0       1
Processing:     0    1   2.0      1     212
Waiting:        0    1   2.0      1     212
Total:          0    1   2.0      1     213

Percentage of the requests served within a certain time (ms)
  50%      1
  66%      1
  75%      1
  80%      1
  90%      1
  95%      2
  98%      2
  99%      3
 100%    213 (longest request)

```

#### 2.6 RPUSH指令  （异常情况）（OK）

##### 2.6.1 中间件

```php
<?php

$redis = new Redis();

try{
    //connect 是 异常级别
    $redis->connect('/tmp/redis.socks');

  $ret = $redis->rPush("test","val1");  //由于test 键已经和上面的set冲突，所以会出错
    var_dump($ret);
}catch (\Exception $ex){
    var_dump($ex->getMessage());
}
```

运行结果：bool(false)

##### 2.6.2 标准集群

```php
<?php

try{
    //connect 是 异常级别
    $redis = new RedisCluster(NULL, Array("127.0.0.1:9001"), 1.5, 1.5, true);

    $ret = $redis->rPush("test","val1");
    var_dump($ret);

}catch (\Exception $ex){
    var_dump($ex->getMessage());
}
```

运行结果：bool(false)

##### 2.6.3 压测数据对比

```shell
# 中间件

corerman@corerman-WorkStation:~$ ab -n 100000 -c 20 http://lab.test.local/redis_agent.php
This is ApacheBench, Version 2.3 <$Revision: 1807734 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking lab.test.local (be patient)
Completed 10000 requests
Completed 20000 requests
Completed 30000 requests
Completed 40000 requests
Completed 50000 requests
Completed 60000 requests
Completed 70000 requests
Completed 80000 requests
Completed 90000 requests
Completed 100000 requests
Finished 100000 requests


Server Software:        nginx
Server Hostname:        lab.test.local
Server Port:            80

Document Path:          /redis_agent.php
Document Length:        12 bytes

Concurrency Level:      20
Time taken for tests:   5.777 seconds
Complete requests:      100000
Failed requests:        0
Total transferred:      19100000 bytes
HTML transferred:       1200000 bytes
Requests per second:    17309.96 [#/sec] (mean)
Time per request:       1.155 [ms] (mean)
Time per request:       0.058 [ms] (mean, across all concurrent requests)
Transfer rate:          3228.71 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   0.1      0       2
Processing:     0    1   2.4      1     213
Waiting:        0    1   2.4      1     213
Total:          0    1   2.4      1     213

Percentage of the requests served within a certain time (ms)
  50%      1
  66%      1
  75%      1
  80%      1
  90%      2
  95%      2
  98%      2
  99%      3
 100%    213 (longest request)
```

```shell
# 标准集群

corerman@corerman-WorkStation:~$ ab -n 100000 -c 20 http://lab.test.local/redis_cluster.php
This is ApacheBench, Version 2.3 <$Revision: 1807734 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking lab.test.local (be patient)
Completed 10000 requests
Completed 20000 requests
Completed 30000 requests
Completed 40000 requests
Completed 50000 requests
Completed 60000 requests
Completed 70000 requests
Completed 80000 requests
Completed 90000 requests
Completed 100000 requests
Finished 100000 requests


Server Software:        nginx
Server Hostname:        lab.test.local
Server Port:            80

Document Path:          /redis_cluster.php
Document Length:        12 bytes

Concurrency Level:      20
Time taken for tests:   5.570 seconds
Complete requests:      100000
Failed requests:        0
Total transferred:      19100000 bytes
HTML transferred:       1200000 bytes
Requests per second:    17952.40 [#/sec] (mean)
Time per request:       1.114 [ms] (mean)
Time per request:       0.056 [ms] (mean, across all concurrent requests)
Transfer rate:          3348.54 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   0.1      0       1
Processing:     0    1   1.9      1     210
Waiting:        0    1   1.9      1     210
Total:          0    1   1.9      1     210

Percentage of the requests served within a certain time (ms)
  50%      1
  66%      1
  75%      1
  80%      1
  90%      1
  95%      2
  98%      2
  99%      3
 100%    210 (longest request)

```

#### 2.7 RPUSH指令  （成功情况）（OK）

##### 2.7.1 中间件

```php
<?php

$redis = new Redis();

try{
    //connect 是 异常级别
    $redis->connect('/tmp/redis.socks');

    $ret = $redis->rPush("pushtest1","val1");
    var_dump($ret);
}catch (\Exception $ex){
    var_dump($ex->getMessage());
}
```

运行结果：int(1)

##### 2.7.2 标准集群

```php
<?php

try{
    //connect 是 异常级别
    $redis = new RedisCluster(NULL, Array("127.0.0.1:9001"), 1.5, 1.5, true);

    $ret = $redis->rPush("pushtest2","val1");
    var_dump($ret);

}catch (\Exception $ex){
    var_dump($ex->getMessage());
}
```

运行结果：int(1)

##### 2.7.3 压测数据对比

```shell
# 中间件  压测后计数正常
corerman@corerman-WorkStation:~$ ab -n 100000 -c 20 http://lab.test.local/redis_agent.php
This is ApacheBench, Version 2.3 <$Revision: 1807734 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking lab.test.local (be patient)
Completed 10000 requests
Completed 20000 requests
Completed 30000 requests
Completed 40000 requests
Completed 50000 requests
Completed 60000 requests
Completed 70000 requests
Completed 80000 requests
Completed 90000 requests
Completed 100000 requests
Finished 100000 requests


Server Software:        nginx
Server Hostname:        lab.test.local
Server Port:            80

Document Path:          /redis_agent.php
Document Length:        7 bytes

Concurrency Level:      20
Time taken for tests:   6.132 seconds
Complete requests:      100000
Failed requests:        99992
   (Connect: 0, Receive: 0, Length: 99992, Exceptions: 0)
Total transferred:      18988900 bytes
HTML transferred:       1088900 bytes
Requests per second:    16307.69 [#/sec] (mean)
Time per request:       1.226 [ms] (mean)
Time per request:       0.061 [ms] (mean, across all concurrent requests)
Transfer rate:          3024.07 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   0.1      0       1
Processing:     0    1   1.7      1     213
Waiting:        0    1   1.7      1     213
Total:          0    1   1.7      1     213

Percentage of the requests served within a certain time (ms)
  50%      1
  66%      1
  75%      1
  80%      1
  90%      2
  95%      2
  98%      3
  99%      3
 100%    213 (longest request)

```

```shell
# 标准集群  压测后计数正常
corerman@corerman-WorkStation:~$ ab -n 100000 -c 20 http://lab.test.local/redis_cluster.php
This is ApacheBench, Version 2.3 <$Revision: 1807734 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking lab.test.local (be patient)
Completed 10000 requests
Completed 20000 requests
Completed 30000 requests
Completed 40000 requests
Completed 50000 requests
Completed 60000 requests
Completed 70000 requests
Completed 80000 requests
Completed 90000 requests
Completed 100000 requests
Finished 100000 requests


Server Software:        nginx
Server Hostname:        lab.test.local
Server Port:            80

Document Path:          /redis_cluster.php
Document Length:        7 bytes

Concurrency Level:      20
Time taken for tests:   5.558 seconds
Complete requests:      100000
Failed requests:        99991
   (Connect: 0, Receive: 0, Length: 99991, Exceptions: 0)
Total transferred:      18988895 bytes
HTML transferred:       1088895 bytes
Requests per second:    17992.50 [#/sec] (mean)
Time per request:       1.112 [ms] (mean)
Time per request:       0.056 [ms] (mean, across all concurrent requests)
Transfer rate:          3336.50 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   0.1      0       3
Processing:     0    1   2.3      1     213
Waiting:        0    1   2.3      1     213
Total:          0    1   2.4      1     213

Percentage of the requests served within a certain time (ms)
  50%      1
  66%      1
  75%      1
  80%      1
  90%      1
  95%      2
  98%      2
  99%      3
 100%    213 (longest request)

```

#### 2.8 LPOP指令（OK）

##### 2.8.1 中间件

```php
<?php

$redis = new Redis();

try{
    //connect 是 异常级别
    $redis->connect('/tmp/redis.socks');

    $ret = $redis->lPop("pushtest1");
    var_dump($ret);
}catch (\Exception $ex){
    var_dump($ex->getMessage());
}
```

结果：可以正常消费，并且当没有数据后 返回false

##### 2.8.2 标准集群

```php
<?php

try{
    //connect 是 异常级别
    $redis = new RedisCluster(NULL, Array("127.0.0.1:9001"), 1.5, 1.5, true);

    $ret = $redis->lPop("pushtest2");
    var_dump($ret);

}catch (\Exception $ex){
    var_dump($ex->getMessage());
}
```

结果：可以正常消费，并且当没有数据后 返回false

##### 2.8.3 压测数据对比

```shell
# 中间件

corerman@corerman-WorkStation:~$ ab -n 100000 -c 20 http://lab.test.local/redis_agent.php
This is ApacheBench, Version 2.3 <$Revision: 1807734 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking lab.test.local (be patient)
Completed 10000 requests
Completed 20000 requests
Completed 30000 requests
Completed 40000 requests
Completed 50000 requests
Completed 60000 requests
Completed 70000 requests
Completed 80000 requests
Completed 90000 requests
Completed 100000 requests
Finished 100000 requests


Server Software:        nginx
Server Hostname:        lab.test.local
Server Port:            80

Document Path:          /redis_agent.php
Document Length:        17 bytes

Concurrency Level:      20
Time taken for tests:   5.839 seconds
Complete requests:      100000
Failed requests:        97496
   (Connect: 0, Receive: 0, Length: 97496, Exceptions: 0)
Total transferred:      19112520 bytes
HTML transferred:       1212520 bytes
Requests per second:    17126.52 [#/sec] (mean)
Time per request:       1.168 [ms] (mean)
Time per request:       0.058 [ms] (mean, across all concurrent requests)
Transfer rate:          3196.59 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   0.1      0       1
Processing:     0    1   2.7      1     213
Waiting:        0    1   2.7      1     213
Total:          0    1   2.7      1     213

Percentage of the requests served within a certain time (ms)
  50%      1
  66%      1
  75%      1
  80%      1
  90%      2
  95%      2
  98%      3
  99%      3
 100%    213 (longest request)

```

```shell
# 标准集群

corerman@corerman-WorkStation:~$ ab -n 100000 -c 20 http://lab.test.local/redis_cluster.php
This is ApacheBench, Version 2.3 <$Revision: 1807734 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking lab.test.local (be patient)
Completed 10000 requests
Completed 20000 requests
Completed 30000 requests
Completed 40000 requests
Completed 50000 requests
Completed 60000 requests
Completed 70000 requests
Completed 80000 requests
Completed 90000 requests
Completed 100000 requests
Finished 100000 requests


Server Software:        nginx
Server Hostname:        lab.test.local
Server Port:            80

Document Path:          /redis_cluster.php
Document Length:        17 bytes

Concurrency Level:      20
Time taken for tests:   5.419 seconds
Complete requests:      100000
Failed requests:        47803
   (Connect: 0, Receive: 0, Length: 47803, Exceptions: 0)
Total transferred:      19360985 bytes
HTML transferred:       1460985 bytes
Requests per second:    18453.22 [#/sec] (mean)
Time per request:       1.084 [ms] (mean)
Time per request:       0.054 [ms] (mean, across all concurrent requests)
Transfer rate:          3488.99 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   0.1      0       1
Processing:     0    1   1.8      1     209
Waiting:        0    1   1.8      1     209
Total:          0    1   1.8      1     209

Percentage of the requests served within a certain time (ms)
  50%      1
  66%      1
  75%      1
  80%      1
  90%      1
  95%      2
  98%      2
  99%      3
 100%    209 (longest request)

```

#### 2.9 MGET指令（OK）

##### 2.9.1 中间件

```php
<?php

$redis = new Redis();

try{
    //connect 是 异常级别
    $redis->connect('/tmp/redis.socks');

    $ret = $redis->mget(["test1","test2","test3","test4","test5","test6","test7","test8","test9","test10","test11","test12","test13","test14","test15","test16","test17","test18","test19","test20"]);
    var_dump($ret);
}catch (\Exception $ex){
    var_dump($ex->getMessage());
}
```

运行结果：

```
array(20) { [0]=> string(6) "value1" [1]=> string(6) "value2" [2]=> bool(false) [3]=> bool(false) [4]=> bool(false) [5]=> bool(false) [6]=> bool(false) [7]=> bool(false) [8]=> bool(false) [9]=> bool(false) [10]=> bool(false) [11]=> bool(false) [12]=> bool(false) [13]=> bool(false) [14]=> bool(false) [15]=> bool(false) [16]=> bool(false) [17]=> bool(false) [18]=> bool(false) [19]=> bool(false) }
```

##### 2.9.2 标准集群

```php
<?php

try{
    //connect 是 异常级别
    $redis = new RedisCluster(NULL, Array("127.0.0.1:9001"), 1.5, 1.5, true);

    $ret = $redis->mget(["test1","test2","test3","test4","test5","test6","test7","test8","test9","test10","test11","test12","test13","test14","test15","test16","test17","test18","test19","test20"]);
    var_dump($ret);

}catch (\Exception $ex){
    var_dump($ex->getMessage());
}
```

运行结果：

```
array(20) { [0]=> string(6) "value1" [1]=> string(6) "value2" [2]=> bool(false) [3]=> bool(false) [4]=> bool(false) [5]=> bool(false) [6]=> bool(false) [7]=> bool(false) [8]=> bool(false) [9]=> bool(false) [10]=> bool(false) [11]=> bool(false) [12]=> bool(false) [13]=> bool(false) [14]=> bool(false) [15]=> bool(false) [16]=> bool(false) [17]=> bool(false) [18]=> bool(false) [19]=> bool(false) }
```

##### 2.9.3 压测数据对比

```shell
# 中间件

corerman@corerman-WorkStation:~$ ab -n 100000 -c 20 http://lab.test.local/redis_agent.php
This is ApacheBench, Version 2.3 <$Revision: 1807734 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking lab.test.local (be patient)
Completed 10000 requests
Completed 20000 requests
Completed 30000 requests
Completed 40000 requests
Completed 50000 requests
Completed 60000 requests
Completed 70000 requests
Completed 80000 requests
Completed 90000 requests
Completed 100000 requests
Finished 100000 requests


Server Software:        nginx
Server Hostname:        lab.test.local
Server Port:            80

Document Path:          /redis_agent.php
Document Length:        478 bytes

Concurrency Level:      20
Time taken for tests:   8.120 seconds
Complete requests:      100000
Failed requests:        0
Total transferred:      65700000 bytes
HTML transferred:       47800000 bytes
Requests per second:    12315.93 [#/sec] (mean)
Time per request:       1.624 [ms] (mean)
Time per request:       0.081 [ms] (mean, across all concurrent requests)
Transfer rate:          7901.92 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   0.1      0       1
Processing:     0    1   2.5      1     214
Waiting:        0    1   2.5      1     214
Total:          0    2   2.5      1     215

Percentage of the requests served within a certain time (ms)
  50%      1
  66%      2
  75%      2
  80%      2
  90%      2
  95%      3
  98%      3
  99%      4
 100%    215 (longest request)

```

```shell
# 标准集群

corerman@corerman-WorkStation:~$ ab -n 100000 -c 20 http://lab.test.local/redis_cluster.php
This is ApacheBench, Version 2.3 <$Revision: 1807734 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking lab.test.local (be patient)
Completed 10000 requests
Completed 20000 requests
Completed 30000 requests
Completed 40000 requests
Completed 50000 requests
Completed 60000 requests
Completed 70000 requests
Completed 80000 requests
Completed 90000 requests
Completed 100000 requests
Finished 100000 requests


Server Software:        nginx
Server Hostname:        lab.test.local
Server Port:            80

Document Path:          /redis_cluster.php
Document Length:        478 bytes

Concurrency Level:      20
Time taken for tests:   13.117 seconds
Complete requests:      100000
Failed requests:        0
Total transferred:      65700000 bytes
HTML transferred:       47800000 bytes
Requests per second:    7623.54 [#/sec] (mean)
Time per request:       2.623 [ms] (mean)
Time per request:       0.131 [ms] (mean, across all concurrent requests)
Transfer rate:          4891.28 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   0.0      0       1
Processing:     1    3   2.4      2     213
Waiting:        1    3   2.4      2     213
Total:          1    3   2.4      2     213

Percentage of the requests served within a certain time (ms)
  50%      2
  66%      3
  75%      3
  80%      3
  90%      4
  95%      4
  98%      5
  99%      5
 100%    213 (longest request)

```

#### 2.10 DEL指令（OK）

##### 2.10.1 中间件

```php
<?php

$redis = new Redis();

try{
    //connect 是 异常级别
    $redis->connect('/tmp/redis.socks');

    $ret = $redis->mset(["test1"=>'value1',"test2"=>'value2']);
    var_dump($ret);
    $ret = $redis->del("test1","test2","test3");
    var_dump($ret);
}catch (\Exception $ex){
    var_dump($ex->getMessage());
}
```

运行结果：bool(true) int(2)

##### 2.10.2 标准集群

```php
<?php

try{
    //connect 是 异常级别
    $redis = new RedisCluster(NULL, Array("127.0.0.1:9001"), 1.5, 1.5, true);
    $ret = $redis->mset(["test1"=>'value1',"test2"=>'value2']);
    var_dump($ret);
    $ret = $redis->del("test1","test2","test3");
    var_dump($ret);

}catch (\Exception $ex){
    var_dump($ex->getMessage());
}

```

运行结果：bool(true) int(2)

##### 2.10.3 压测数据对比

```shell
# 中间件
corerman@corerman-WorkStation:~$ ab -n 100000 -c 20 http://lab.test.local/redis_agent.php
This is ApacheBench, Version 2.3 <$Revision: 1807734 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking lab.test.local (be patient)
Completed 10000 requests
Completed 20000 requests
Completed 30000 requests
Completed 40000 requests
Completed 50000 requests
Completed 60000 requests
Completed 70000 requests
Completed 80000 requests
Completed 90000 requests
Completed 100000 requests
Finished 100000 requests


Server Software:        nginx
Server Hostname:        lab.test.local
Server Port:            80

Document Path:          /redis_agent.php
Document Length:        7 bytes

Concurrency Level:      20
Time taken for tests:   7.240 seconds
Complete requests:      100000
Failed requests:        0
Total transferred:      18600000 bytes
HTML transferred:       700000 bytes
Requests per second:    13811.28 [#/sec] (mean)
Time per request:       1.448 [ms] (mean)
Time per request:       0.072 [ms] (mean, across all concurrent requests)
Transfer rate:          2508.69 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   0.1      0       1
Processing:     0    1   2.6      1     215
Waiting:        0    1   2.6      1     215
Total:          0    1   2.6      1     215

Percentage of the requests served within a certain time (ms)
  50%      1
  66%      1
  75%      2
  80%      2
  90%      2
  95%      2
  98%      3
  99%      4
 100%    215 (longest request)

```

```shell
# 标准集群

corerman@corerman-WorkStation:~$ ab -n 100000 -c 20 http://lab.test.local/redis_cluster.php
This is ApacheBench, Version 2.3 <$Revision: 1807734 $>
Copyright 1996 Adam Twiss, Zeus Technology Ltd, http://www.zeustech.net/
Licensed to The Apache Software Foundation, http://www.apache.org/

Benchmarking lab.test.local (be patient)
Completed 10000 requests
Completed 20000 requests
Completed 30000 requests
Completed 40000 requests
Completed 50000 requests
Completed 60000 requests
Completed 70000 requests
Completed 80000 requests
Completed 90000 requests
Completed 100000 requests
Finished 100000 requests


Server Software:        nginx
Server Hostname:        lab.test.local
Server Port:            80

Document Path:          /redis_cluster.php
Document Length:        7 bytes

Concurrency Level:      20
Time taken for tests:   6.447 seconds
Complete requests:      100000
Failed requests:        0
Total transferred:      18600000 bytes
HTML transferred:       700000 bytes
Requests per second:    15511.04 [#/sec] (mean)
Time per request:       1.289 [ms] (mean)
Time per request:       0.064 [ms] (mean, across all concurrent requests)
Transfer rate:          2817.44 [Kbytes/sec] received

Connection Times (ms)
              min  mean[+/-sd] median   max
Connect:        0    0   0.1      0       1
Processing:     0    1   3.1      1     216
Waiting:        0    1   3.1      1     216
Total:          0    1   3.1      1     216

Percentage of the requests served within a certain time (ms)
  50%      1
  66%      1
  75%      1
  80%      1
  90%      2
  95%      2
  98%      3
  99%      4
 100%    216 (longest request)
```

# RedisHub 与 phpredis集群客户端指令效果对比

## 一. set指令 （保持一致）

1. 正常：true
2. 节点损坏：报异常
3. clusterDown：返回异常，clusterdown异常



## 二、mset （保持一致）

1. 正常 ：true
2. 节点损坏：报异常
3. clusterDown：返回异常，clusterdown异常



## 三、get （保持一致）
1. 正常：数据
2. 节点损坏：报异常
3. clusterDown：返回异常，clusterdown异常


## 四、mget （节点损坏时有区别，redishub更合理）
1. 正常：返回数据 ，无数据时为false
2. 节点损坏： phpredis全部不返回，redishub针对存活的数据节点返回数据，不存活的节点返回nil及false
3. clusterDown：返回异常，clusterdown异常



### 五、DEL 

1. 正常：返回删除数据量

2. 节点损坏：phpredis报异常、redishub针对存活的数据节点进行数据删除，并统计数量返回，redishub不报异常

3. clusterDown：返回异常，clusterdown异常

   

### 六.rpush指令 （保持一致）

1. 正常 返回：统计量

2. 节点损坏：报异常

3. clusterDown：返回异常，clusterdown异常

   

### 七.lpop指令 （保持一致）

1. 正常 返回：统计量
2. 节点损坏：报异常
3. clusterDown：返回异常，clusterdown异常