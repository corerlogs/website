# 1.7 集群 MGET 指令支持

业务系统为了提高多个key的数据获取吞吐，经常会采用mget指令，这个指令在单实例模式的redis场景下能够完美支持，但是redis标准集群不支持跨槽位执行mget指令。

但是mget针对业务环境是大量使用的，所以中间件必须完成mget指令在集群中的命令支持。

## 1.7.1 指令转换
由于Redis不支持跨槽位执行mget指令，因此我们可以变相思维，总体的指令转换如下：
1.	针对MGET指令的keys进行拆分。
2.	对keys进行hash计算 => 选择key所对应的node 。
3. 针对node组上的指令进行并发 pipline命令发送。
4. 聚合各个并发线程的指令结果，把远端redis集群内部的数据返回给业务调用方。

## 1.7.2 MGET指令设计图
针对MGET的具体工作情况，我这边绘制了一个图，说明MGET的具体工作原理，红色线路代表一次完整的MGET执行周期。
![](https://doc.icorer.com/uploads/redisHub/images/m_ff6b6701d7c5aaa75ea3e086c2def5b5_r.png)

从上面的图形可以看出，中间件接受到MGET请求后，会把指令中的KYES进行hash计算、并结合node信息选择数据存储的node，针对每个node进行进行pipeline 指令流水吞吐、保障单node下的吞吐高性能，针对不同的node进行并发执行，通过并发技术提高MGET在集群环境下的整体响应速度。