# NetHandle
这是一个库,方便构建高性能TCP服务端应用程序,站在Go语言的巨人肩膀上

项目地址: uriModule/NetHandle

## 一. 特点

1. 高性能,低资源消耗
2. 非常简单易用的开发接口
3. 支持众多协议,TCP,UDP,UNIX

## 二. 安装

go get -u moduleUri/NetHandle



## 三. 性能测试:

### 3.1  50*10000 (50线程  X  10000请求)

![](https://blog.icorer.com/usr/uploads/2019/01/1394302958.png)

![](https://blog.icorer.com/usr/uploads/2019/01/3786025671.png)

### 3.2  50*20000 (50线程  X  20000请求)

![](https://blog.icorer.com/usr/uploads/2019/01/1563343670.png)

### 3.3  100*10000 (100线程  X  10000请求)

![](https://blog.icorer.com/usr/uploads/2019/01/1257587320.png)


## 四. 样例代码:

使用这个库的时候,只需要自定义简单的回调函数,即可构造出性能强悍的网络监听.

```go
package main

import (
	"fmt"
	"moduleUri/NetHandle"
	"log"
	"sync"
)

var addrTcp = "127.0.0.1:10000"

func main() {
	log.SetFlags(log.Lshortfile | log.LstdFlags)

	var mu sync.RWMutex
	count := 0
	go log.Printf("started server at %s", addrTcp)

	err := NetHandle.ListenAndServe("tcp", addrTcp,
		func(conn NetHandle.Conn) {

			requestData := make([]byte, 512)

			_, err := conn.NetConn().Read(requestData)

			if err != nil {
				conn.Close()
				return
			}

			mu.Lock()
			count++
			mu.Unlock()

			countCurrent := 0

			mu.RLock()
			countCurrent = count
			mu.RUnlock()

			replyData := fmt.Sprintf("%d\r\n", countCurrent)
			conn.NetConn().Write(append([]byte(replyData)))

		},
		func(conn NetHandle.Conn) bool {
			// use this function to accept or deny the connection.
			log.Printf("accept: %s", conn.RemoteAddr())
			return true
		},
		func(conn NetHandle.Conn, err error) {
			// this is called when the connection has been closed
			log.Printf("closed: %s, err: %v", conn.RemoteAddr(), err)
		},
	)
	if err != nil {
		log.Fatal(err)
	}
}

```