# 1.9 Redis集群状态更新

RedisHub中间件除了要沟通客户端 与 服务端 这两方，还需要及时获取Redis集群的状态信息，并把状态信息转换或更新必要的内存数据结构，内存数据结构最终会被中间件用来承载redis请求。

## 1.9.1 状态信息来源

集群状态信息的来源主要包括：
1.	被动方式：集群内部指令执行周期内的MOVE、ASK信号
2. 主动方式：集群 CLUSTER SLOTS 指令

## 1.9.2 集群槽位状态信息更新
关于集群槽位的信息更新，我们主要包括以下两方面策略：
1.	为了具备更好的性能，我们采用chan 共享内存监听
2.	采用读写锁，提高关键内存共享区的读写安全性及性能
3. 针对更新操作做了秒级限流操作，保障中间件的稳定性。

核心源码分析 如下：
```go
func (cluster *Cluster) handleUpdate() {
	for {
	//获取chan列表的更新信号
		msg := <-cluster.updateList

		// TODO: control update frequency by updateTime and movedTime?
		cluster.rwLock.RLock()
		clusterLastUpdateTime := cluster.updateTime
		cluster.rwLock.RUnlock()

		//如果集群的上一次更新时间 加上窗口值（1s） 小于 此次集群更新指令产生的时间: 证明集群更新频率过高，控制频率。
		if clusterLastUpdateTime.Add(1 * time.Second).Before(msg.movedTime) {
			//针对集群进行状态更新
			err := cluster.Update(msg.node)
			if err != nil {
				log.Printf("handleUpdate: %v\n", err)
				go KafkaLoger.Errorf("redistun handleUpdate wrong. err: %s", err.Error())
			}

		}
	}
}
```


## 1.9.2 指令MOVE 、ASK 信号跟踪
如果客户端在请求redis集群的过程中、redis集群出现集群槽位重新分配，会对于请求产生MOVE、ASK信号，为了让中间件支持数据的无缝迁移，我们针对MOVE、ASK进行了特殊处理。

核心源码分析 如下：

```go
	// 检查回复类型
	resp := checkReply(reply)

	switch (resp) {
	case kRespOK, kRespError:
		return reply, nil
	case kRespMove:
		//此处在高并发+slots循环多次集中迁移时，会出现数据的多级别MOVE，对于多级别MOVE 要进行到底，一般频率为20万次中出现10次
		//所以采用循环进行多级MOVE处理
		for {
			//尝试第一次MOVE，并对结果进行判断，如果reply类型不再是MOVE类型，则证明摆脱多级MOVE，则把结果返回出去
			//由于结果可能会发生变化，因此再进行判断
			reply, err = cluster.handleMove(node, reply.(redisError).Error(), cmd, args)

			respType := checkReply(reply)

			//如果reply类型不是MOVE类型，则 准备跳出循环、对结果进行判断，选择条件返回
			if respType != kRespMove {

				switch (respType) {
				case kRespOK, kRespError:
					return reply, nil
				case kRespAsk:
					return cluster.handleAsk(node, reply.(redisError).Error(), cmd, args)
				case kRespConnTimeout:
					return cluster.handleConnTimeout(node, cmd, args)
				case kRespClusterDown: //如果redis集群宕机，则返回宕机错误
					//选取可用的节点 更新集群状态信息
					cluster.UpdateSlotsInfoByRandomNode(node)
					return reply, Cluster_Down_Error
				}

				//此处return为了跳出多级MOVE的for循环
				return reply, err
			}

		}
		//return cluster.handleMove(node, reply.(redisError).Error(), cmd, args)
	case kRespAsk:
		return cluster.handleAsk(node, reply.(redisError).Error(), cmd, args)
	case kRespConnTimeout:
		return cluster.handleConnTimeout(node, cmd, args)
	case kRespClusterDown: //如果redis集群宕机，则返回宕机错误
		//选取可用的节点 更新集群状态信息
		cluster.UpdateSlotsInfoByRandomNode(node)
		return reply, Cluster_Down_Error
	}
```