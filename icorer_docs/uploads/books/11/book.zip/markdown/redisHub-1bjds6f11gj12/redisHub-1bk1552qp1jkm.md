# 1.8 TCP连接池

### 1.8.1  连接池是什么

我们常见的池很多，比如内存池，线程池，对象池，连接池等。顾名思义，池子干的事情都是一样的，把一类相同的事物放到一个池里面，已备不时之需，好比我们的蓄水池一样，把平日多余的水储蓄起来，一方面防止洪水到来时候对下游造成洪涝灾害，另一方面还可以合理灌溉资源利用，比如还可以水力发电。同样连接池是把已经已经建立好的连接放入一个池子，当请求到来可以直接拿来使用，这样就即解决了频繁的创建关闭连接带来的开销，也保护了后端服务，防止同时有大量连接涌入，造成危害。

### 1.8.2  连接池的种类
其实也就是连接池的使用场景

1. 可以是一个独立部署的服务，通过套接字提供代理服务。例如我们的常用的dbproxy。

2. 可以是一个服务内部进程间共享的连接池，这种相对更加轻量，可以理解为项目级别，只对内提供服务。

3.  进程内的连接池，更加轻量，当前进程内的线程或者协程可以使用。

RedisHub 实现的连接池就是 进程内的连接池，使用连接池有以下好处：
1.	减少客户端使用连接时，创建和销毁连接的时间和系统资源开销，这里涉及到TCP的三次握手也四次挥手，还有TCP的慢启动预热。
2.	避免极端情况大量连接直接涌入后端服务，对整个系统服务造成危害。

但同时也有一些缺点，比如空闲状态下也要维护一定数量的连接，占用客户端和服务端的资源，这里可以根据实际需求动态调配连接数，达到效率和资源利用的平衡。哪有一点资源不占用，还想系统高效稳定的事情，建个水坝还得占片地，护坝人间断性的职守呢。

### 1.8.3 TCP连接池初始化方式
TCP连接池的最终目标就是对程序体内部需要使用的TCP连接进行池化管理，连接不够使用时自动扩容、连接过剩的时候能够自动回收，所以 我们首先需要考虑TCP连接池的初始化方式。连接池的初始化方式主要包括如下两种：

1. 当请求到来的时候，尝试从连接池中获取连接对象，如果连接池为空，创建连接对象，请求结束的时候，归还至连接池.

2. 进程启动的时候，创建固定数量的连接对象，当请求到来的时候，尝试从连接池中获取连接对象，如果连接池为空，继续等待或者服务降级; 不为空的话正常服务，请求结束的时候，归还至连接池.

RedisHub 中间件的TCP连接池初始化方式选择第一种。针对第二种连接池的实现方案，可以查阅本人另外一个项目RedisTun。

### 1.8.4 连接池源码分析 - 获取一个可用链接

```go
func (node *redisNode) getConn() (*redisConn, error) {

	//需要针对当前的redis-node的tcp连接池进行内存操作，在并发场景下，首先先上锁。
	node.mutex.Lock()

//如果当前node已经进入不可用状态。
	if node.closed {  
		node.mutex.Unlock()
		return nil, fmt.Errorf("getConn: connection has been closed")
	}

	//从TCP连接池中清理陈旧的TCP连接，这里面使用了LIST数据结构，可以把陈旧连接进行归并、一并处理。
	//如果连接远程node节点时候设置了TCP连接存活时间 则 进行检验。
	if node.aliveTime > 0 {
		for {
			//从list中选择一个元素，如果conns列表为空 则跳出检查
			elem := node.conns.Back()
			if elem == nil {
				break
			}

			//成功获取到一条TCP连接，进行生命期时间校验
			conn := elem.Value.(*redisConn)

			//如果当前获取的TCP连接是在合法生命周期内部的，立刻退出，但是这个元素还在list中，下次获取仍然能够获取到
			if conn.t.Add(node.aliveTime).After(time.Now()) {
				break
			}

			//运行到这里，代表TCP连接生命期超时，删除此元素
			node.conns.Remove(elem)
		}
	}

	//经过前面的操作，前面目的在于清理超时TCP连接
	if node.conns.Len() <= 0 {
		//没有TCP连接可用，所以需要新建连接，立刻需要释放锁
		node.mutex.Unlock()

		c, err := net.DialTimeout("tcp", node.address, node.connTimeout)

		if err != nil {
			return nil, err
		}

		//var writerMemory bytes.Buffer
		
		//创建新的redis连接内存对象
		conn := &redisConn{
			c:            c,
			br:           bufio.NewReader(c),
			bw:           bufio.NewWriter(c),
			readTimeout:  node.readTimeout,
			writeTimeout: node.writeTimeout,
			//writerMemory: &writerMemory,
		}

		//设置内存缓冲区
		//conn.bwm = RedSHandle.NewWriterHandle(conn.writerMemory)
		//conn.readerParser = RedisFastParser.NewParserHandle(conn.c)

		return conn, nil
	}

	//获取到一条已经存在的存活TCP连接，这条TCP的生命周期也在合法时间内，所以：
	// 1.取出元素
	// 2.删除元素在list中的位置
	// 3.立刻解锁
	elem := node.conns.Back()
	node.conns.Remove(elem)
	node.mutex.Unlock()

	//重置内存缓冲区
	//elem.Value.(*redisConn).writerMemory.Reset()
	return elem.Value.(*redisConn), nil
}
```

### 1.8.5 连接池源码分析 -  放回可用连接进入池

```go
func (node *redisNode) releaseConn(conn *redisConn) {

	//需要针对当前的redis-node的tcp连接池进行内存操作，在并发场景下，首先先上锁。
	node.mutex.Lock()
	defer node.mutex.Unlock()

	//连接仍然有待处理的回复，只需将其关闭即可，避免可能的TCP粘包连接。
	if conn.pending > 0 || node.closed {
		conn.shutdown()
		return
	}

	//如果连接池的当前长度已经超过池的最高界限，或者node没有开启tcp存活时间选项。
	if node.conns.Len() >= node.keepAlive || node.aliveTime <= 0 {
		conn.shutdown()
		return
	}

	//更新当前conn的时间，并放入LIST数据结构
	conn.t = time.Now()
	node.conns.PushFront(conn)

	//重置内存缓冲区
	//conn.writerMemory.Reset()
}
```