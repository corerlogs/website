# 1.2  配置解析器设计
Agent配置器, 主要负责解析来自网络 或者 文件系统中的配置文件,目前提供配置文件解析模块,配置解析器设计主要包括以下部分:

1. 配置信息元素结构.
2. 配置解析器相关解析函数.
3. 配置解析器对外API接口服务,允许动态更新配置.

**组成结构图如下:**
![](https://doc.icorer.com/uploads/redistun/images/m_c9aadcf792a107eb1891cb3eeaac1c6a_r.png)

## 1.2.1 配置信息元素

随着系统功能的不断丰富,系统的配置项目也会越来越多,目前配置解析器主要解析的数据对象包括:

1. 网络配置项 : 针对中间件网络监听进行配置。
2. redis集群配置项：针对Redis集群进行配置。
2. 日志配置项：目前提供kafka或日志输出，kafka支持公司标准日志。

## 1.2.2 配置样例

```yaml
#RedisHub YAML config file

#RedisHub Net Config
net:
  listen_uri: unix:/var/run/redis.sock #Unix Domain Socket的监听路径：PHP推荐使⽤这种模式
#  listen_uri: tcp:10.100.183.180:16379 #TCP的监控IP及端⼝

#RedisHub cluster Config
cluster:
  start_nodes:node1,node2,node3 #Redis集群的节点，这⾥可以根据线上实际情况进⾏配置，多个只是为了保障⾼可⽤
  conn_timeout: 200 #Redis节点的TCP连接超时时间 （单位：毫秒）
  conn_read_timeout: 50 #Redis节点的TCP读取超时时间 （单位：毫秒）
  conn_write_timeout: 50 #Redis节点的TCP写⼊超时时间 （单位：毫秒）
  conn_alive_timeout: 60 #Redis节点的TCP最⼤空闲时间 （单位：秒）
  conn_pool_size: 200 #针对每⼀个Redis集群节点的TCP连接池最⼤值 （单位：个）

#RedisHub api config
api:
  http_listen_address:

#RedisHub log config
# log 相关配置
log:

  # 日否开启日志
  enable: true

  # 日志输出位置，支持std(终端) kafka
  # 注：std仅在调试时使用
  output: "kafka"

  # kafka server的地址 需要修改到指定环境的kafka
  kafka_address: ["10.166.7.139:9092", "10.166.7.139:9093", "10.166.7.139:9094"]

  kafka_info_topic: "ltlog-info"

  kafka_error_topic: "ltlog-error"

  # 日志输出级别控制, 可省略, 默认输出到 error 级别
  # 高级别的可以输出低级别的日志， 级别 trace > debug > error > warning > info
  # 例如 level = error时，不可输出trace和debug级别的日志
  level: "debug"

  #   日志中是否报告函数调用信息,可省略 默认为false
  report_call: false

  # 机器ip，可为空，默认自动查找
  ip: ""

  # 机器hostname，可为空，默认自动查找
  hostname: ""

  # app_name 默认为 RedisHub
  app_name: "RedisHub"

  # 周期上报redis执行信息 （单位：秒）
  heartbeat_report_second: 120

```