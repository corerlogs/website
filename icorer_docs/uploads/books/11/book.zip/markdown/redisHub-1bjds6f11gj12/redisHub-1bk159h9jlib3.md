# 1.10 RESP协议解析

###  1.10.1 RESP协议介绍
Redis 协议在以下三个目标之间进行折中：
1.	易于实现
2.	可以高效地被计算机分析（parse）
3. 可以很容易地被人类读懂

### 1.10.2 请求

Redis 服务器接受命令以及命令的参数。

服务器会在接到命令之后，对命令进行处理，并将命令的回复传送回客户端。

### 1.10.3 回复

Redis 命令会返回多种不同类型的回复。

通过检查服务器发回数据的第一个字节， 可以确定这个回复是什么类型：

* 状态回复（status reply）的第一个字节是 "+"

* 错误回复（error reply）的第一个字节是 "-"

* 整数回复（integer reply）的第一个字节是 ":"

* 批量回复（bulk reply）的第一个字节是 "$"

* 多条批量回复（multi bulk reply）的第一个字节是 "*"

### 1.10.4 状态回复

一个状态回复（或者单行回复，single line reply）是一段以 "+" 开始、 "\r\n" 结尾的单行字符串。

以下是一个状态回复的例子：

> +OK

客户端库应该返回 "+" 号之后的所有内容。 比如在在上面的这个例子中， 客户端就应该返回字符串 "OK" 。

状态回复通常由那些不需要返回数据的命令返回，这种回复不是二进制安全的，它也不能包含新行。

状态回复的额外开销非常少，只需要三个字节（开头的 "+" 和结尾的 CRLF）。

### 1.10.5 错误回复

错误回复和状态回复非常相似， 它们之间的唯一区别是， 错误回复的第一个字节是 "-" ， 而状态回复的第一个字节是 `"+"` 。

错误回复只在某些地方出现问题时发送： 比如说， 当用户对不正确的数据类型执行命令， 或者执行一个不存在的命令， 等等。

一个客户端库应该在收到错误回复时产生一个异常。

以下是两个错误回复的例子：

> -ERR unknown command 'foobar'
-WRONGTYPE Operation against a key holding the wrong kind of value

在 `"-" `之后，直到遇到第一个空格或新行为止，这中间的内容表示所返回错误的类型。

`ERR` 是一个通用错误，而 `WRONGTYPE` 则是一个更特定的错误。 一个客户端实现可以为不同类型的错误产生不同类型的异常， 或者提供一种通用的方式， 让调用者可以通过提供字符串形式的错误名来捕捉（trap）不同的错误。

不过这些特性用得并不多， 所以并不是特别重要， 一个受限的（limited）客户端可以通过简单地返回一个逻辑假（false）来表示一个通用的错误条件。

### 1.10.6 整数回复

整数回复就是一个以 `":"` 开头， CRLF 结尾的字符串表示的整数。

比如说， `":0\r\n" `和` ":1000\r\n"` 都是整数回复。

### 1.10.7 RESP协议解析- 源码分析
这里首先感谢Codis 和 Redigo 这两大开源项目， 这里只进行概括性源码解析。
```go
func (d *Decoder) decodeResp() (*Resp, error) {
	b, err := d.br.ReadByte()  //从缓冲区读取1byte，这个是RESP首特征byte
	if err != nil {
		return nil, errors.Trace(err)
	}
	r := &Resp{}
	r.Type = RespType(b)
	switch r.Type {
	default: //如果不在可控范围，则代表请求不是RESP协议
		return nil, errors.Errorf("bad resp type %s", r.Type)
	case TypeString, TypeError, TypeInt: //如果是字符串、错误、整形响应
		r.Value, err = d.decodeTextBytes()
	case TypeBulkBytes: //如果是Bulk类型
		r.Value, err = d.decodeBulkBytes()
	case TypeArray: //如果数据是数组类型
		r.Array, err = d.decodeArray()
	}
	return r, err
}

//解析非二进制安全的字符串、错误、整形响应，必须按照\r\n分割。
func (d *Decoder) decodeTextBytes() ([]byte, error) {
	b, err := d.br.ReadBytes('\n')
	if err != nil {
		return nil, errors.Trace(err)
	}
	if n := len(b) - 2; n < 0 || b[n] != '\r' {
		return nil, errors.Trace(ErrBadCRLFEnd)
	} else {
		return b[:n], nil
	}
}

//解析数组类型响应。
func (d *Decoder) decodeArray() ([]*Resp, error) {
//解析数组长度
	n, err := d.decodeInt()
	if err != nil {
		return nil, err
	}
	switch {
	case n < -1:
		return nil, errors.Trace(ErrBadArrayLen)
	case n > MaxArrayLen:
		return nil, errors.Trace(ErrBadArrayLenTooLong)
	case n == -1:
		return nil, nil
	}
	//根据数组长度创建RESP数组
	array := make([]*Resp, n)
	for i := range array {
	//针对每个数组元素进行解析，此处类似递归调用，但是，借助go的栈逃逸、堆区内存分配，可以避免循环栈消耗。
		r, err := d.decodeResp()
		if err != nil {
			return nil, err
		}
		array[i] = r
	}
	return array, nil
}

```